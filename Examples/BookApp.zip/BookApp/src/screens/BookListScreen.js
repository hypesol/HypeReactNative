import React from 'react';
import { View, Pressable, Text } from 'react-native';
import Animated, {
  interpolate, withTiming,
  useAnimatedStyle, useSharedValue, useAnimatedScrollHandler, useAnimatedProps,
} from 'react-native-reanimated';
import { useTheme } from '@react-navigation/native';
import { SharedElement } from 'react-navigation-shared-element';
import { AntDesign } from 'react-native-vector-icons';
import LottieView from 'lottie-react-native';
// import * as Haptics from 'expo-haptics';

// import Text from '../components/Text';
import BookList from '../components/BookList';
import { useBooksState } from '../BookStore';

const studies = require('../anims/landscape.json');

const LottieViewAnimated = Animated.createAnimatedComponent(LottieView);

// Get morning, afternoon, evening
const getGreeting = () => {
  const hours = (new Date()).getHours();
  if (hours < 12) {
    return 'Good Morning';
  }
  if (hours >= 12 && hours <= 17) {
    return 'Good Afternoon';
  }
  return 'Good Evening';
};

// home screen
const BookListScreen = ({ navigation }) => {
  return(
  <View><Text>Hello</Text></View>
  );
}

export default BookListScreen;
